package com.example.demo;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	DefaultUserService userService;
	
	
	@GetMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	@GetMapping("/loginsuccess")
	public String loginSuccessPage() {
		return "loginsuccess";
	}
	
	
	@GetMapping("/user")
	public String userDBPage() {
		return "userdb";
	}
	@GetMapping("/admin")
	public String adminDBPage() {
		return "admin/admindb";
	}
	
	@PostMapping("/registerSubmit")
	public String registerSubmit(@RequestParam("username") String username,@RequestParam("email") String email,@RequestParam("password") String password) {
		
		User newUser=new User();
		Role newRole=new Role();
		newRole.setRole("ROLE_USER");
		Set<Role> roles=new HashSet<Role>();
		roles.add(newRole);
		
		newUser.setName(username);
		newUser.setEmail(email);
		BCryptPasswordEncoder passwordEncoder=new BCryptPasswordEncoder();
		String encryptedPW=passwordEncoder.encode(password);
		newUser.setPassword(encryptedPW);
		newUser.setRoles(roles);
		newUser.setEnable(true);	
		
		userRepo.save(newUser);
		
		return "regsuccess";
		
	}

}
